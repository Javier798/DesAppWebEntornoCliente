window.addEventListener("resize", function(){
    
});